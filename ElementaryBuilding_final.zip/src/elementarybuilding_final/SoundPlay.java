/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elementarybuilding_final;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URL;
import javax.sound.sampled.*;

/**
 *
 * @author will9102002
 */
public class SoundPlay {

    public void playSound(String filename) {

        try (InputStream in = getClass().getResourceAsStream(filename)) {
            InputStream bufferedIn = new BufferedInputStream(in);
            try (
                    AudioInputStream audioIn = AudioSystem.getAudioInputStream(bufferedIn)) {
                Clip clip = AudioSystem.getClip();
                clip.open(audioIn);
                clip.start();
            }
        } catch (Exception e) {
           e.printStackTrace();
       }

    }

}
