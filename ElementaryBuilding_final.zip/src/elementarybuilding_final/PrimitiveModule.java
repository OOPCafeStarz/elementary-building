/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elementarybuilding_final;

import java.io.Serializable;


/**
 *
 * @author user
 */

public class PrimitiveModule extends Module implements Serializable{
    
    @Override
    public void execute(){
    
    }
}
