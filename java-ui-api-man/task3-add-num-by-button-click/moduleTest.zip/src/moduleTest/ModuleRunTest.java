package moduleTest;



import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class ModuleRunTest {

	public static void main(String[] args)
	{
		PanelOuter panOut = new PanelOuter();
		JFrame frm = new JFrame("ModulRunTest");
		frm.setBounds(120, 60, 600, 600);
		frm.setLayout(new GridLayout(2, 1, 2, 2));

		PanelOuter.Panel1 panel1 = panOut.new Panel1();
		PanelOuter.Panel3 panel3 = panOut.new Panel3();
		
		frm.add(panel1);frm.add(panel3);

		frm.setVisible(true);
		
		frm.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
	}
}

class PanelOuter
{
	Outer out = new Outer();
	
	class Panel1 extends JPanel
	{
		public Panel1()
		{
			setLayout(new GridLayout(1, 4, 2, 2));
			JButton btn1 = new JButton("1");
			JButton btn2 = new JButton("2");
			JButton btn3 = new JButton("3");
			JButton btn4 = new JButton("4");

			btn1.addMouseListener(out.new Btn1Listen(btn1, btn2, btn3, btn4));
			btn2.addMouseListener(out.new Btn2Listen(btn1, btn2, btn3, btn4));
			btn3.addMouseListener(out.new Btn3Listen(btn1, btn2, btn3, btn4));
			btn4.addMouseListener(out.new Btn4Listen(btn1, btn2, btn3, btn4));

			add(btn1); add(btn2); add(btn3); add(btn4);
		}
	}

	class Panel3 extends JPanel
	{
		public Panel3()
		{
			setLayout(new GridLayout(1, 3, 2, 2));
			JButton btn1 = new JButton("%");
			JButton btn2 = new JButton("^");
			JButton btn3 = new JButton("o");
			
			JLabel[] labelArr = new JLabel[10];
			for(int i = 0; i < labelArr.length; i++)
			{
				labelArr[i] = new JLabel();
				add(labelArr[i]);
			}
		
			btn1.addMouseListener(out.new mode1(this, labelArr));
		
			add(btn1); add(btn2); add(btn3);
		}
	}

}
class Outer
{
	boolean[] check = new boolean[4];
	ArrayList<Integer> list = new ArrayList<Integer>();


	class Define
	{
		String result;
		public String insert(int num)
		{
			switch(num)
			{
			case 1: 
				result = new String("1");
				break;
			case 2:
				result = new String("2");
				break;
			case 3:
				result = new String("3");
				break;
			case 4:
				result = new String("4");
				break;
			}

			return result;
		}
	}

	class mode1 extends MouseAdapter
	{
		String pat;
		JPanel panel3;
		Define judge = new Define();
		JLabel[] labelArr;
		int index = 0;
		
		public mode1(PanelOuter.Panel3 pan, JLabel[] labelArr)
		{
			panel3 = pan;
			this.labelArr = labelArr;
		}
		
		public void mouseReleased(MouseEvent e)
		{
			if(e.getClickCount() == 2)
				System.out.println("Double clicked!");
			else{
				for(int i = 0; i < 4; i++)
				{
					if(check[i] == true)
					{
						list.add(i);
						pat = judge.insert(i + 1);
						labelArr[index++].setText(pat);
					}
				}
			}
		}
	}
	class mode2 extends MouseAdapter
	{
		public void mouseClicked(MouseEvent e)
		{

		}
	}
	class mode3 extends MouseAdapter
	{
		public void mouseClicked(MouseEvent e)
		{

		}
	}

	class Btn1Listen extends MouseAdapter
	{
		JButton btn1;
		JButton btn2;
		JButton btn3;
		JButton btn4;
		
		public Btn1Listen(JButton btn1, JButton btn2, JButton btn3, JButton btn4)
		{
			this.btn1 = btn1;
			this.btn2 = btn2;
			this.btn3 = btn3;
			this.btn4 = btn4;
		}
		
		public void mouseReleased(MouseEvent e)
		{
			
			
			
			check[0] = true;
			check[1] = false;
			check[2] = false;
			check[3] = false;
			
			btn1.setEnabled(false);
			btn2.setEnabled(true);
			btn3.setEnabled(true);
			btn4.setEnabled(true);
		}
		
		
	}
	
	class Btn2Listen extends MouseAdapter
	{
		JButton btn1;
		JButton btn2;
		JButton btn3;
		JButton btn4;

		public Btn2Listen(JButton btn1, JButton btn2, JButton btn3, JButton btn4)
		{
			this.btn1 = btn1;
			this.btn2 = btn2;
			this.btn3 = btn3;
			this.btn4 = btn4;
		}
		public void mouseReleased(MouseEvent e)
		{
			check[0] = false;
			check[1] = true;
			check[2] = false;
			check[3] = false;
			
			btn1.setEnabled(true);
			btn2.setEnabled(false);
			btn3.setEnabled(true);
			btn4.setEnabled(true);
		}
	}
	class Btn3Listen extends MouseAdapter
	{
		JButton btn1;
		JButton btn2;
		JButton btn3;
		JButton btn4;

		public Btn3Listen(JButton btn1, JButton btn2, JButton btn3, JButton btn4)
		{
			this.btn1 = btn1;
			this.btn2 = btn2;
			this.btn3 = btn3;
			this.btn4 = btn4;
		}
		public void mouseReleased(MouseEvent e)
		{
			check[0] = false;
			check[1] = false;
			check[2] = true;
			check[3] = false;
			
			btn1.setEnabled(true);
			btn2.setEnabled(true);
			btn3.setEnabled(false);
			btn4.setEnabled(true);
		}
	}
	class Btn4Listen extends MouseAdapter
	{
		JButton btn1;
		JButton btn2;
		JButton btn3;
		JButton btn4;

		public Btn4Listen(JButton btn1, JButton btn2, JButton btn3, JButton btn4)
		{
			this.btn1 = btn1;
			this.btn2 = btn2;
			this.btn3 = btn3;
			this.btn4 = btn4;
		}
		public void mouseReleased(MouseEvent e)
		{
			check[0] = false;
			check[1] = false;
			check[2] = false;
			check[3] = true;
			
			btn1.setEnabled(true);
			btn2.setEnabled(true);
			btn3.setEnabled(true);
			btn4.setEnabled(false);
		}
	}
}

